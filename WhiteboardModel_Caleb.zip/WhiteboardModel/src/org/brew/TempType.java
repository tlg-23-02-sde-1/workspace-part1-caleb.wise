package org.brew;

public enum TempType {
    HOT, ICED;
}