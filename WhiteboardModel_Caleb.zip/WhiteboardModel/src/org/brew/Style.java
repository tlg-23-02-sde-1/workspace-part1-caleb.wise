package org.brew;

public enum Style {
    AMERICANO, LATTE, BREVE, MOCHA, DRIP
}